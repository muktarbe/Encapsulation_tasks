import java.time.LocalDate;

public class University {
    private String name;
    private String address;
    private LocalDate opening_date;

    public University() {

    }

    public University(String name, String address, LocalDate opening_date) {
        this.name = name;
        this.address = address;
        this.opening_date = opening_date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDate getOpening_date() {
        return opening_date;
    }

    public void setOpening_date(LocalDate opening_date) {
        this.opening_date = opening_date;
    }

    @Override
    public String toString() {
        return "University \n" +
                "name = " + name + "\n"+
                ", address = " + address + "\n"+
                ", opening date = " + opening_date+"\n"+"\n";
    }
}
