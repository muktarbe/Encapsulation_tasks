import java.time.LocalDate;
import java.util.Arrays;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        University university1 = new University();
        university1.setName("Токтогул Сатылганов");
        university1.setAddress("Чуйская 345");
        university1.setOpening_date(LocalDate.of(2000,5,5));

        University university2 = new University();
        university2.setName("Чынгыз Айтматов");
        university2.setAddress("Киевская 345");
        university2.setOpening_date(LocalDate.of(1999,10,10));

       University [] universities = {university1,university2};

//        System.out.println(Arrays.toString(universities));

        School school1 = new School();
        school1.setName("school 24");
        school1.setAddress("Чапаева 33");

        School school2 = new School();
        school2.setName("school 132");
        school2.setAddress("Суборова 33");

        School [] schools = {school1,school2};

//        System.out.println(Arrays.toString(schools));

        Car car1 = new Car();
        car1.setMarca("Мерсадес");
        car1.setSpeed(110);
        car1.setVolume(2.6);

        Car car2 = new Car();
        car2.setMarca("BMW");
        car2.setSpeed(200);
        car2.setVolume(4.6);

        Car [] car = {car1,car2};

        System.out.println(Arrays.toString(car));


    }
}