public class Car {
    private String marca;
    private int speed;
    private double volume;

    public Car() {

    }

    public Car(String marca, int speed, double volume) {
        this.marca = marca;
        this.speed = speed;
        this.volume = volume;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    @Override
    public String toString() {
        return "Car \n" +
                "marca = " + marca + "\n" +
                ", speed = " + speed +"\n" +
                ", volume = " + volume +"\n" +"\n" ;
    }
}
